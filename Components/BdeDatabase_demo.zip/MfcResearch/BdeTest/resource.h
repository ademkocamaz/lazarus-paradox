//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BdeTest.rc
//
#define IDD_BDETEST_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_TEST_CONNECTION             1000
#define IDB_APPEND                      1001
#define IDB_EDIT                        1002
#define ET_CHAR                         1003
#define ET_SHORT                        1004
#define ET_LONG                         1005
#define ET_FLOAT                        1006
#define ET_CURRENCY                     1007
#define ET_LOGICAL                      1008
#define ET_DATE                         1009
#define ET_TIME                         1010
#define ET_TIMESTAMP                    1011
#define ET_MEMO                         1012
#define IDB_FIRST                       1013
#define IDB_CONNECT                     1014
#define IDB_PRIOR                       1015
#define IDB_NEXT                        1016
#define IDB_LAST                        1017
#define IDB_INSERT                      1018
#define IDB_CANCEL_EDIT                 1019
#define IDB_POST                        1020
#define ET_BCD                          1021
#define IDB_DISCONNECT                  1022
#define IDB_DELETE                      1023
#define ET_SHORT_TYPE                   1024
#define ET_LONG_TYPE                    1025
#define ET_FLOAT_TYPE                   1026
#define ET_CURRENCY_TYPE                1027
#define ET_DATE_TYPE                    1029
#define ET_TIME_TYPE                    1030
#define ET_TIMESTAMP_TYPE               1031
#define ET_BCD_TYPE                     1032
#define CB_LOGICAL_TYPE                 1033
#define IDB_SET_TYPE_VALUES             1034
#define IDB_SET_BLANK                   1035
#define IDB_CONNECT_DBASE               1036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
